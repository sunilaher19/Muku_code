#include "../include/common.hpp"


class FeedHandler
{
    public:
        FeedHandler();
        void processMessage(const std::string &line);
        void printCurrentOrderBook(std::ostream &os) const;

        //SellMap
        using priroityMap = map<int, OrderDetails>;
        using priceMap = map<double , priroityMap>;
        int ttv=0;

        priceMap sellMap;
        priceMap buyMap;

        string OrderSide;

        void CheckSell(OrderDetails&); //MLA change name
        void CheckBuy(OrderDetails&); ////MLA change name
        void CheckAndInsertInMap(priceMap&, OrderDetails& orderDetails);
        bool Cancel(priceMap&, OrderDetails& );
        void Execution(priceMap&, priceMap& );
        void ModifyBestBuySell();

        inline int  findBestBuy(priceMap& buyMap)
        {
            cout << "buyMap.size() " << buyMap.size() <<endl;
            if(buyMap.size() > 0)
            {
                auto a = buyMap.rbegin()->first;
                return a;
            }
            else
            {
                return  -1;
            }
            
        }
        inline int findBestSell(priceMap& sellMap)
        {
            cout << "sellMap.size() " << sellMap.size() <<endl;
            if(sellMap.size() > 0)
                return sellMap.begin()->first;
            else
                return 0;
        }   


        
};