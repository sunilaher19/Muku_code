#include<iostream>
#include<fstream>
#include <boost/algorithm/string.hpp> 
#include<map>
#include<unordered_map>
#include<sstream>
using namespace std;


struct OrderDetails
{
    string OrderId;
    double OrderPrice;
    int OrderQty;

    std::string ToString() const
    {
        stringstream os;
        os << "OrderId = " << OrderId << " OrderPrice=" << OrderPrice << " OrderQty=" << OrderQty ;
        return os.str();

    }
};
