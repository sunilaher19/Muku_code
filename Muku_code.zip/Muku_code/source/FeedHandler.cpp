#include "../include/FeedHandler.hpp"


FeedHandler::FeedHandler()
{
    cout << "FeedHandler::FeedHandler" <<endl;
}

void FeedHandler::processMessage(const std::string &line)
{   
    //cout << "FeedHandler::processMessage" << line << endl; 
    vector<string> tokenizer; 
    boost::split(tokenizer, line, boost::is_any_of(",")); 

    OrderDetails orderDetails;
    auto Feild = tokenizer[0];
    //cout << "Feild : " << Feild <<endl;
    if(Feild == "A")
    {
        cout << "Add Order " << endl ; //MLA
        OrderSide = tokenizer[2];
        orderDetails.OrderQty = atoi(tokenizer[3].c_str());
        orderDetails.OrderPrice = atol(tokenizer[4].c_str());
        orderDetails.OrderId = tokenizer[1];
        if(OrderSide == "B")
        {
            CheckBuy(orderDetails);
        }
        else if(OrderSide == "S")
        {
            CheckSell(orderDetails);
        }
    }
    else if(Feild == "X")
    {
        cout << "Cancel order" << endl;
        OrderSide = tokenizer[2];
        orderDetails.OrderQty = atoi(tokenizer[3].c_str());
        orderDetails.OrderPrice = atol(tokenizer[4].c_str());
        orderDetails.OrderId = tokenizer[1];
        if(OrderSide == "B")
        {
            Cancel(buyMap, orderDetails);
        }
        else if(OrderSide == "S")
        {
            Cancel(sellMap, orderDetails);
        }
       
    }
    else if(Feild == "M")
    {
        cout << "Modifyed order" << endl;
        OrderSide = tokenizer[2];
        orderDetails.OrderQty = atoi(tokenizer[3].c_str());
        orderDetails.OrderPrice = atol(tokenizer[4].c_str());
        orderDetails.OrderId = tokenizer[1];   
        //Modify cause cahnge in Piroritu so deleting and reinserting value
        if(OrderSide == "B")
        {
            if(Cancel(buyMap, orderDetails))
                CheckBuy(orderDetails);
            else
            {
                cout << "Order not found for " << orderDetails.ToString();
            }
            
        }
        else if(OrderSide == "S")
        {
            if(Cancel(sellMap, orderDetails))
                CheckBuy(orderDetails);
            else
            {
                cout << "Order not found for " << orderDetails.ToString();
            }
        }   
    }
    else
    {
        cout << "Invalid order type" <<endl;
        return;    
    }
}

bool FeedHandler::Cancel(priceMap& dataMap, OrderDetails& orderDetails)
{
    auto datamapIter = dataMap.find(orderDetails.OrderPrice);
    if( datamapIter != dataMap.end())
    {
        for(auto value : datamapIter->second)
        {
            if(value.second.OrderId == orderDetails.OrderId)
            {
                cout << "Dekleting = " << value.first << ":" << value.second.ToString() << endl;
                datamapIter->second.erase(value.first);
                break;
            }
        }

        if(datamapIter->second.size() ==0)
        {
            dataMap.erase(orderDetails.OrderPrice);
        }
        return true;
    }
    return false;
}

void FeedHandler::CheckSell(OrderDetails& orderDetails)
{
    cout << "CheckSell " << orderDetails.ToString() <<endl ;
    CheckAndInsertInMap(sellMap, orderDetails);
    Execution(sellMap, buyMap);
}

void FeedHandler::CheckBuy(OrderDetails& orderDetails)
{
    //check if you have any exuction
    cout << "CheckBuy " <<  orderDetails.ToString() <<endl;
    CheckAndInsertInMap(buyMap, orderDetails);
    Execution(sellMap, buyMap);
    
}

void FeedHandler::ModifyBestBuySell()
{

}


void FeedHandler::CheckAndInsertInMap(priceMap& dataMap, OrderDetails& orderDetails)
{
    cout << "CheckAndInsertInMap " << orderDetails.ToString() <<endl;
    auto dataMapiter = dataMap.find(orderDetails.OrderPrice);
    if( dataMapiter == dataMap.end())
    {
        cout << "Inserting firste elment" << endl;
        priroityMap priroityData;
        priroityData.emplace(1, orderDetails);
        dataMap.emplace(orderDetails.OrderPrice, priroityData);
    }
    else
    {
        auto rev_iter = dataMapiter->second.rbegin()->first;
        cout << "rev_iter =" << rev_iter << endl;
        dataMapiter->second.emplace(++rev_iter, orderDetails);
    }
}

//sell max vlue should be equal/les than buy

//is buy mean order is bought
void FeedHandler::Execution(priceMap& sellMap, priceMap& buyMap)
{
    cout << "FeedHandler::Execution"  << endl;

    
    while(true)
    {
        //double BestBuy =0 , BestSell =0;

        auto BestBuyPrice = findBestBuy(buyMap);
        auto BestSellprice = findBestSell(sellMap);
        cout << "BestSellprice = " << BestSellprice << " BestBuyPrice=" << BestBuyPrice <<  endl;


        if( BestSellprice <= BestBuyPrice && BestSellprice > 0 && BestBuyPrice > 0 )
        {
            //Execution and upodate map
            auto Siter = sellMap.find(BestSellprice)->second.begin();
            auto Biter = buyMap.find(BestBuyPrice)->second.begin();
            cout << "Siter->second.=" << Siter->second.ToString() << endl;  
            cout << "Biter->second.=" << Biter->second.ToString() << endl;

            if(Siter->second.OrderQty == Biter->second.OrderQty)
            {
                cout << "case1 " << endl;
                sellMap.find(BestSellprice)->second.erase(Siter->first);
                buyMap.find(BestBuyPrice)->second.erase(Biter->first);
            }
            else if(Siter->second.OrderQty > Biter->second.OrderQty)
            {
                cout << "case2 " << endl;
                Siter->second.OrderQty -= Biter->second.OrderQty;
                buyMap.find(BestBuyPrice)->second.erase(Biter->first);
            }
            else if(Siter->second.OrderQty < Biter->second.OrderQty)
            {
                cout << "case3 " << Biter->second.OrderQty << ":" <<  Siter->second.OrderQty << endl;
                Biter->second.OrderQty -= Siter->second.OrderQty;
                sellMap.find(BestSellprice)->second.erase(Siter->first);
                cout << "case3 end" << endl;
            }
            else
            {
                cout << "Some issue please check" << endl;
                break;
            }

            if(sellMap.find(BestSellprice)->second.size()==0)
            {
                sellMap.erase(BestSellprice);
            }
            if(buyMap.find(BestBuyPrice)->second.size()==0)
            {
                buyMap.erase(BestBuyPrice);
            }
            BestSellprice =0;
            BestBuyPrice =-1;
        }
        else
        {
            break;
        }   
    }
    

}

void FeedHandler::printCurrentOrderBook(std::ostream &os) const
{
    cout << "FeedHandler::printCurrentOrderBook "  << sellMap.size() << ":" <<  buyMap.size() << endl;

    //print map
    for(auto i : sellMap)
    {
        cout << " sellMap value " << i.first << ":" ;
        for(auto j : i.second)
        {
            cout  << " " << j.first << ":" << j.second.ToString() << " ";
        }
        cout << endl;
    }

    for(auto i : buyMap)
    {
        cout << " BuyMap value " << i.first << ":" ;
        for(auto j : i.second)
        {
            cout << " " << j.first << ":" << j.second.ToString() << " "; 
        }
        cout << endl;
    }
}

