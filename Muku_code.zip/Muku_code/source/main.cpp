
#include "../include/FeedHandler.hpp"


int main(int argc, char **argv)
{
    if(argc < 2)
    {
        cout << "ERROR: Less then one Arguemnt" << endl;
        return -1;
    }
    FeedHandler feed;
    std::string line;
    const std::string filename(argv[1]);
    std::ifstream infile(filename.c_str(), ios::in);
    int counter = 0;
    while (std::getline(infile, line)) {
        feed.processMessage(line);
        /*if (++counter % 10 == 0) 
        {
            feed.printCurrentOrderBook(std::cerr);
        }*/
    }
    feed.printCurrentOrderBook(std::cout);
    return 0;
}